import { useState, useEffect } from "react"
import {
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Area,
  ComposedChart,
} from "recharts"
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Calendar,
  Award,
  AlertTriangle,
  HelpCircle,
  Activity,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  ShieldAlert,
  Clock,
  CheckCircle2,
} from "lucide-react"
import type { TrendsIntelligenceResponse } from "@/types/intelligence"

interface TrendsIntelligenceViewProps {
  datasetId: string
  initialData?: TrendsIntelligenceResponse | null
}

export function TrendsIntelligenceView({
  datasetId,
  initialData,
}: TrendsIntelligenceViewProps) {
  const [data, setData] = useState<TrendsIntelligenceResponse | null>(initialData ?? null)
  const [granularity, setGranularity] = useState<string>("auto")
  const [selectedMetric, setSelectedMetric] = useState<string>("")
  const [selectedCategory, setSelectedCategory] = useState<string>("")
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  const fetchTrends = async (g: string, m?: string, c?: string) => {
    setLoading(true)
    setError(null)
    try {
      const params = new URLSearchParams()
      if (g) params.set("granularity", g)
      if (m) params.set("metric", m)
      if (c) params.set("category_col", c)

      const res = await fetch(`/api/dataset/${datasetId}/trends?${params.toString()}`)
      if (!res.ok) {
        throw new Error(`Failed to load trends intelligence: ${res.statusText}`)
      }
      const json: TrendsIntelligenceResponse = await res.json()
      setData(json)
      if (json.selected_metric) setSelectedMetric(json.selected_metric)
      if (json.selected_granularity) setGranularity(json.selected_granularity)
    } catch (err: any) {
      setError(err.message || "Failed to load trend analysis.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!initialData) {
      fetchTrends(granularity)
    } else {
      setData(initialData)
      if (initialData.selected_metric) setSelectedMetric(initialData.selected_metric)
      if (initialData.selected_granularity) setGranularity(initialData.selected_granularity)
    }
  }, [datasetId, initialData])

  const handleGranularityChange = (newG: string) => {
    setGranularity(newG)
    fetchTrends(newG, selectedMetric, selectedCategory)
  }

  const handleMetricChange = (newM: string) => {
    setSelectedMetric(newM)
    fetchTrends(granularity, newM, selectedCategory)
  }

  const handleCategoryChange = (newC: string) => {
    setSelectedCategory(newC)
    fetchTrends(granularity, selectedMetric, newC)
  }

  if (loading && !data) {
    return (
      <div className="flex h-64 items-center justify-center rounded-xl border border-border bg-card p-6">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Activity className="h-4 w-4 animate-spin text-primary" />
          Computing multi-granularity trends, moving averages, and period comparisons...
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-6 text-center text-sm text-rose-600">
        {error}
      </div>
    )
  }

  if (!data || !data.has_time_dimension) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card/50 p-8 text-center space-y-3">
        <Clock className="mx-auto h-10 w-10 text-muted-foreground/60" />
        <h3 className="text-base font-semibold text-foreground">No Valid Time Dimension Detected</h3>
        <p className="max-w-md mx-auto text-xs text-muted-foreground">
          {data?.time_validation.notes?.[0] ??
            "This dataset does not contain a recognizable date, timestamp, or year column. Time-series trends, period comparisons, and forecasting require at least one time dimension."}
        </p>
        {data?.available_metrics && data.available_metrics.length > 0 && (
          <div className="pt-2 text-xs text-muted-foreground">
            Available numerical measures found: <span className="font-mono text-foreground">{data.available_metrics.join(", ")}</span>
          </div>
        )}
      </div>
    )
  }

  const timeVal = data.time_validation
  const comp = data.period_comparison
  const answers = data.practical_answers

  return (
    <div className="space-y-6">
      {/* 1. Time Dimension Health Banner */}
      <div className="rounded-xl border border-border bg-card p-4 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-foreground">
                  Time Dimension: <span className="font-mono text-primary">{timeVal.time_column}</span>
                </h3>
                <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="h-3 w-3" />
                  {timeVal.detected_frequency?.toUpperCase()} FREQUENCY
                </span>
                {timeVal.has_irregular_intervals && (
                  <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium bg-amber-500/10 text-amber-600 dark:text-amber-400">
                    <AlertTriangle className="h-3 w-3" />
                    Irregular intervals
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                Range: <strong>{timeVal.date_range?.min_date}</strong> to <strong>{timeVal.date_range?.max_date}</strong> ({timeVal.date_range?.total_days} days, {timeVal.date_range?.observation_count?.toLocaleString()} observations)
              </p>
            </div>
          </div>

          {/* Granularity & Metric Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 bg-muted/60 p-1 rounded-lg border border-border">
              {(["D", "W", "M", "Q", "Y"] as const).map((g) => (
                <button
                  key={g}
                  onClick={() => handleGranularityChange(g)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    granularity === g
                      ? "bg-background text-foreground shadow-xs"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {g === "D" ? "Daily" : g === "W" ? "Weekly" : g === "M" ? "Monthly" : g === "Q" ? "Quarterly" : "Yearly"}
                </button>
              ))}
            </div>

            {data.available_metrics.length > 1 && (
              <select
                value={selectedMetric}
                onChange={(e) => handleMetricChange(e.target.value)}
                className="h-8 rounded-md border border-input bg-background px-2.5 py-1 text-xs font-medium text-foreground focus:outline-hidden focus:ring-1 focus:ring-ring"
              >
                {data.available_metrics.map((m) => (
                  <option key={m} value={m}>
                    {m.replace(/_/g, " ").toUpperCase()}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>
      </div>

      {/* 2. Period-over-Period KPI Row */}
      {comp && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl border border-border bg-card p-4 shadow-xs space-y-1">
            <span className="text-xs font-medium text-muted-foreground">Current vs Previous Period</span>
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-bold text-foreground">{comp.current_val.toLocaleString()}</span>
              {comp.pct_change !== null && (
                <span
                  className={`inline-flex items-center text-xs font-semibold ${
                    comp.pct_change > 0
                      ? "text-emerald-600 dark:text-emerald-400"
                      : comp.pct_change < 0
                      ? "text-rose-600 dark:text-rose-400"
                      : "text-muted-foreground"
                  }`}
                >
                  {comp.pct_change > 0 ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
                  {comp.pct_change > 0 ? "+" : ""}
                  {comp.pct_change}%
                </span>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Prior: {comp.previous_val.toLocaleString()} (Δ {comp.absolute_change > 0 ? "+" : ""}{comp.absolute_change.toLocaleString()})
            </p>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 shadow-xs space-y-1">
            <span className="text-xs font-medium text-muted-foreground">All-Time Peak (Best Period)</span>
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4 text-amber-500" />
              <span className="text-xl font-bold text-foreground">{comp.best_val?.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground">Recorded on: <strong>{comp.best_period}</strong></p>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 shadow-xs space-y-1">
            <span className="text-xs font-medium text-muted-foreground">All-Time Trough (Lowest Period)</span>
            <div className="flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-muted-foreground" />
              <span className="text-xl font-bold text-foreground">{comp.worst_val?.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground">Recorded on: <strong>{comp.worst_period}</strong></p>
          </div>

          <div className="rounded-xl border border-border bg-card p-4 shadow-xs space-y-1">
            <span className="text-xs font-medium text-muted-foreground">Trend Stability & Volatility</span>
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />
              <span className="text-base font-semibold text-foreground">{data.stability_rating}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              CV: <strong>{data.volatility_cv ?? "N/A"}</strong> | Spikes: <strong>{data.spikes_and_drops.length}</strong>
            </p>
          </div>
        </div>
      )}

      {/* 3. Main Interactive Trend Chart */}
      <div className="rounded-xl border border-border bg-card p-5 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-foreground capitalize">
              {data.selected_metric?.replace(/_/g, " ")} Trend & Moving Averages
            </h3>
            <p className="text-xs text-muted-foreground">
              Factual progression aggregated by {granularity}-period with 3-period and 7-period rolling baselines.
            </p>
          </div>
          {data.spikes_and_drops.length > 0 && (
            <div className="flex items-center gap-1.5 rounded-md bg-amber-500/10 px-2.5 py-1 text-xs font-medium text-amber-600 dark:text-amber-400">
              <ShieldAlert className="h-3.5 w-3.5" />
              <span>{data.spikes_and_drops.length} Anomaly Spikes/Drops Flagged</span>
            </div>
          )}
        </div>

        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={data.time_series} margin={{ top: 10, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.5} />
              <XAxis
                dataKey="formatted_date"
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
              />
              <YAxis
                stroke="var(--muted-foreground)"
                fontSize={11}
                tickLine={false}
                tickFormatter={(v) => Number(v).toLocaleString()}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  borderColor: "var(--border)",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: any, name: any) => [Number(value).toLocaleString(), name]}
              />
              <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
              <Area
                type="monotone"
                dataKey="value"
                name="Actual Value"
                fill="var(--primary)"
                fillOpacity={0.12}
                stroke="var(--primary)"
                strokeWidth={2}
              />
              <Line
                type="monotone"
                dataKey="moving_avg_3"
                name="3-Period Moving Avg"
                stroke="#9333ea"
                strokeWidth={2}
                dot={false}
                strokeDasharray="4 4"
              />
              <Line
                type="monotone"
                dataKey="moving_avg_7"
                name="7-Period Moving Avg"
                stroke="#f59e0b"
                strokeWidth={1.5}
                dot={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* 4. Category / Entity Breakdown over Time */}
      {data.category_trends.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-5 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-primary" />
                <h3 className="text-base font-semibold text-foreground">
                  Category Performance & Growth Breakdown
                </h3>
              </div>
              <p className="text-xs text-muted-foreground">
                Period-over-period growth and decline across leading segments.
              </p>
            </div>
            {data.available_categories.length > 1 && (
              <select
                value={selectedCategory}
                onChange={(e) => handleCategoryChange(e.target.value)}
                className="h-8 rounded-md border border-input bg-background px-2.5 py-1 text-xs font-medium text-foreground focus:outline-hidden focus:ring-1 focus:ring-ring"
              >
                {data.available_categories.map((c) => (
                  <option key={c} value={c}>
                    Breakdown by {c.replace(/_/g, " ").toUpperCase()}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-border bg-muted/40 text-muted-foreground">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">Category / Entity</th>
                  <th className="py-2.5 px-3 font-semibold">Prior Value</th>
                  <th className="py-2.5 px-3 font-semibold">Latest Value</th>
                  <th className="py-2.5 px-3 font-semibold">Absolute Change</th>
                  <th className="py-2.5 px-3 font-semibold">Growth Rate</th>
                  <th className="py-2.5 px-3 font-semibold">Direction</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {data.category_trends.map((cat, i) => {
                  const isUp = cat.direction === "increasing"
                  const isDown = cat.direction === "decreasing"
                  return (
                    <tr key={i} className="hover:bg-muted/20 transition-colors">
                      <td className="py-2.5 px-3 font-medium text-foreground">{cat.category}</td>
                      <td className="py-2.5 px-3 text-muted-foreground">{cat.previous_val.toLocaleString()}</td>
                      <td className="py-2.5 px-3 font-semibold text-foreground">{cat.current_val.toLocaleString()}</td>
                      <td className="py-2.5 px-3 font-mono">
                        {cat.absolute_change > 0 ? "+" : ""}
                        {cat.absolute_change.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 font-mono">
                        {cat.pct_change !== null ? `${cat.pct_change > 0 ? "+" : ""}${cat.pct_change}%` : "N/A"}
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                            isUp
                              ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                              : isDown
                              ? "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {isUp ? <TrendingUp className="h-3 w-3" /> : isDown ? <TrendingDown className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
                          {cat.direction}
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. 12 Practical Trend Questions & Answers Card */}
      {answers && (
        <div className="rounded-xl border border-border bg-card p-5 shadow-xs space-y-4">
          <div className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4 text-primary" />
            <h3 className="text-base font-semibold text-foreground">
              Practical Trend Questions Answered
            </h3>
          </div>
          <p className="text-xs text-muted-foreground">
            Structured business insights derived directly from mathematical calculations without speculative claims.
          </p>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 pt-2">
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">1. Metric Analyzed</span>
              <p className="text-xs font-semibold text-foreground">{answers.metric_analyzed}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">2. Previous Value</span>
              <p className="text-xs font-semibold text-foreground">{answers.previous_value_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">3. Current Value</span>
              <p className="text-xs font-semibold text-foreground">{answers.current_value_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">4. Absolute Change</span>
              <p className="text-xs font-semibold text-foreground">{answers.absolute_change_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">5. Percentage Change</span>
              <p className="text-xs font-semibold text-foreground">{answers.pct_change_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">6. Peak Period</span>
              <p className="text-xs font-semibold text-foreground">{answers.best_period_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">7. Trough Period</span>
              <p className="text-xs font-semibold text-foreground">{answers.worst_period_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">8. Growing Categories</span>
              <p className="text-xs font-semibold text-foreground">
                {answers.categories_increased.length > 0 ? answers.categories_increased.join(", ") : "None recorded"}
              </p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">9. Declining Categories</span>
              <p className="text-xs font-semibold text-foreground">
                {answers.categories_declined.length > 0 ? answers.categories_declined.join(", ") : "None recorded"}
              </p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">10. Stability & Volatility</span>
              <p className="text-xs font-semibold text-foreground">{answers.stability_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">11. Spikes & Outliers</span>
              <p className="text-xs font-semibold text-foreground">{answers.outliers_text}</p>
            </div>
            <div className="rounded-lg border border-border/80 bg-muted/20 p-3 space-y-1 sm:col-span-2 lg:col-span-3">
              <span className="text-xs font-medium text-muted-foreground">12. Next Investigation Recommendation</span>
              <p className="text-xs text-foreground mt-0.5">{answers.next_investigation_text}</p>
            </div>
          </div>
        </div>
      )}

      {/* 6. Spikes & Drops Details */}
      {data.spikes_and_drops.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-5 shadow-xs space-y-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-amber-500" />
            <h3 className="text-sm font-semibold text-foreground">
              Statistical Spikes & Drops Log
            </h3>
          </div>
          <div className="space-y-2">
            {data.spikes_and_drops.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-lg border border-border/70 bg-muted/30 p-3 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-flex items-center rounded-full px-2 py-0.5 font-semibold ${
                      item.type === "spike"
                        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                        : "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                    }`}
                  >
                    {item.type.toUpperCase()}
                  </span>
                  <span className="font-semibold text-foreground">{item.date}:</span>
                  <span className="text-muted-foreground">{item.description}</span>
                </div>
                <div className="font-mono text-muted-foreground">
                  Expected: {item.expected_value.toLocaleString()} | Actual: <strong>{item.value.toLocaleString()}</strong>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. Limitations & Analytical Integrity Notice */}
      <div className="rounded-xl border border-border bg-muted/30 p-4 text-xs text-muted-foreground space-y-1.5">
        <div className="flex items-center gap-1.5 font-semibold text-foreground">
          <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
          <span>Analytical Integrity & Limitations</span>
        </div>
        <ul className="list-disc list-inside space-y-1 pl-1">
          {data.limitations.map((lim, i) => (
            <li key={i}>{lim}</li>
          ))}
        </ul>
      </div>
    </div>
  )
}
