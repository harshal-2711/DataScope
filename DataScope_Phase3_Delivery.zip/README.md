# DataScope

A professional, dataset-agnostic data analysis and decision-intelligence platform.
DataScope helps users load, explore, and understand any tabular dataset without
assuming a specific domain (it is not e-commerce-specific and never hard-codes
column names).

## Technology Stack

**Frontend**
- React + TypeScript
- Vite
- Tailwind CSS v4
- shadcn/ui
- React Router

**Backend**
- Python
- FastAPI
- Uvicorn

## Architecture

```
DataScope/
├── frontend/   # React SPA — UI only, no business logic
└── backend/    # FastAPI service — API and (future) analytics logic
```

- Frontend and backend are fully separate applications communicating over HTTP.
- UI components never contain analysis/business logic; that logic lives in the backend.
- No dataset-specific assumptions (column names, industry, etc.) are hard-coded anywhere.
- Raw datasets are never modified in place (enforced from Phase 2 onward).

## Setup Instructions

### Prerequisites
- Node.js 18+ and npm
- Python 3.10+

### Frontend
```powershell
cd frontend
npm install
```

### Backend
```powershell
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Run Instructions

### Start the backend (port 8000)
```powershell
cd backend
venv\Scripts\activate
uvicorn app.main:app --reload --port 8000
```

### Start the frontend (port 5173)
```powershell
cd frontend
npm run dev
```

Visit `http://localhost:5173`. The Overview page shows a live backend connection
status pulled from `GET /api/health`.

## Current Development Phase

**Phase 3 — Trends Intelligence & Real-World Domain Analytics ✅**

DataScope has evolved into an intelligent, universal analytics platform that analyzes datasets according to their actual domain and answers practical business and domain questions without random charts or unsupported claims:

1. **Intelligent Domain Playbooks & Detection**:
   - Classifies tabular data across 75+ specialized domain blueprints (Sales/Retail, IPL & Cricket [match-level & ball-by-ball], Finance, Marketing, Education, Healthcare, HR, Operations, Entertainment, etc.).
   - Transparent domain evidence, confidence scoring (0.0–1.0), and graceful fallback to generic analytics without hallucinating business metrics for non-business domains.
   - Strict domain safety: no revenue/profit metrics for Cricket or Healthcare data; descriptive statistics only for Healthcare without medical diagnoses.

2. **Trends Intelligence Engine**:
   - **Time Dimension Validation**: Automatic identification of date/timestamp columns, parsing validation, interval frequency detection (Daily, Weekly, Monthly, Quarterly, Yearly, Irregular), and non-uniform interval detection.
   - **Multi-Granularity Aggregation**: Dynamic time-series aggregation with user-switchable granularities (Daily, Weekly, Monthly, Quarterly, Yearly).
   - **Period-over-Period Comparisons**: Current vs Previous period calculations, absolute difference, percentage change, and identification of all-time peaks and troughs.
   - **Rolling Averages & Volatility**: 3-period and 7-period moving averages, standard deviation of changes, Coefficient of Variation (CV), and stability classification (`Stable`, `Moderate Volatility`, `High Volatility`).
   - **Anomaly & Spike/Drop Detection**: Identifies periods deviating $> 2\sigma$ from the rolling baseline with clear logs.
   - **Category Growth Breakdown**: Segment-level time series identifying which categories increased vs declined period-over-period.
   - **12 Practical Trend Questions**: Structured answers to key analytical questions (metric analyzed, current vs prior values, peak/trough, growing/declining segments, volatility, next recommended investigations).

3. **Statistical Forecasting Module (Optional)**:
   - Evaluates prerequisites (valid time column, $\ge 6$ historical observations, continuous numeric metric).
   - Fits **Holt's Linear Exponential Smoothing** (level and trend) with $80\%$ and $95\%$ analytical confidence intervals.
   - Computes in-sample accuracy metrics (MAPE, RMSE, MAE) and model confidence score.
   - Interactive horizon controls (+3, +6, +12, +24 periods).
   - Explicit analytical disclaimer: forecasts are mathematical extrapolations of historical patterns, not guaranteed outcomes.
   - Graceful unavailable state with actionable checklist when prerequisites are not met.

4. **Comprehensive Data Quality & Hygiene Engine**:
   - Scores dataset quality on a 0–100 scale (`Healthy`, `Warning`, `Critical`).
   - Checks: missing value percentages, duplicate rows, duplicate primary IDs, invalid/mixed dates, irregular intervals, suspicious negative values in naturally non-negative measures, zero denominators, and extreme statistical outliers ($3\times \text{IQR}$).
   - Generates actionable recommendations and column-level hygiene diagnostics.

5. **Universal Descriptive Statistics**:
   - Parametric and non-parametric stats for all columns (mean, median, mode, variance, std dev, IQR, percentiles P25/P50/P75/P90/P99, skewness, frequency distribution, and Pearson correlation matrix).

6. **Frontend Dashboards**:
   - **Trends Intelligence Page** (`/trends`): Interactive time health banner, granularity/metric controls, period comparison KPIs, ComposedChart with moving averages, category growth table, 12 practical answers, and spike/drop logs.
   - **Forecasting Page** (`/forecast`): Interactive horizon switching, combined historical + forecast chart with shaded confidence bands, accuracy metrics, and disclaimers.
   - **Dataset Hygiene Audit** (`/dataset`): Embedded Data Quality card showing overall health score, critical/warning issues, and hygiene recommendations.
   - **Explore & Decision Analytics** (`/explore`): Executive summary, domain playbooks, validation banner, entity badges, and drill-down charts.

## API Endpoints

- `POST /api/dataset/upload` — In-memory upload and summary generation
- `GET /api/dataset/{dataset_id}/intelligence` — Full 15-step domain intelligence pipeline
- `GET /api/dataset/{dataset_id}/trends` — Time-series trends intelligence and period comparisons
- `GET /api/dataset/{dataset_id}/forecast` — Holt's linear exponential smoothing forecast
- `GET /api/dataset/{dataset_id}/data_quality` — Comprehensive data quality and hygiene report
- `GET /api/dataset/{dataset_id}/statistics` — Universal parametric and non-parametric statistics
- `GET /api/dataset/{dataset_id}/decision_dashboard` — Executive decision-oriented dashboard
- `GET /api/dataset/{dataset_id}/recommendations` — Auto-ranked chart recommendations
- `GET /api/dataset/{dataset_id}/drilldown` — Multi-level filtered drilldown aggregations

## Testing Instructions

### Run All Backend Unit & Integration Tests (42 tests):
```powershell
cd backend
.\venv\Scripts\python -m unittest discover -s tests -p "test_*.py"
```

### Run End-to-End Real Data Verifications (9 datasets):
```powershell
cd backend
.\venv\Scripts\python -m tests.verify_phase3_e2e
```

### Run Frontend Production Build & Typechecks:
```powershell
cd frontend
npm run build
```

## Roadmap (Summary)

- **Phase 1** — Foundation ✅
- **Phase 2** — Dataset ingestion and profiling ✅
- **Phase 3** — Trends Intelligence & Real-World Domain Analytics ✅ (Completed)
- **Phase 4** — Deep Risk and Scenario Simulation
- **Phase 5** — Automated Multi-Format Report Generation


