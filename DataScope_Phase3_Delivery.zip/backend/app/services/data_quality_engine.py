"""Comprehensive Data Quality & Hygiene Validation Engine.

Performs robust verification of:
- Missing values and completeness percentages
- Duplicate rows and candidate ID duplicates
- Invalid dates, mixed formats, and irregular intervals
- Suspicious negative values in non-negative domains
- Zero denominators / division-by-zero hazards
- Extreme statistical outliers (3x IQR and Z > 3)
- Inconsistent categories (casing differences, trailing whitespace)
- Empty columns and constant-value columns
- Insufficient sample size
- Overall Data Quality Score (0-100) and actionable recommendations
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Literal, Optional, Tuple

import numpy as np
import pandas as pd

from app.domains.base import DomainBlueprint
from app.domains.registry import get_blueprint_by_id
from app.schemas.domain_blueprint import (
    ColumnQualityDiagnosticSchema,
    DataQualityCheckSchema,
    DataQualityReportResponse,
    DomainIdentitySchema,
)


def compute_data_quality_report(
    df: pd.DataFrame,
    dataset_id: str,
    domain: Optional[DomainIdentitySchema] = None,
) -> DataQualityReportResponse:
    """Run full data quality and hygiene inspection on a DataFrame."""
    checks: List[DataQualityCheckSchema] = []
    column_diagnostics: Dict[str, ColumnQualityDiagnosticSchema] = {}
    recommendations: List[str] = []

    total_rows = len(df)
    total_cols = len(df.columns)
    score = 100

    # 1. Sample Size Check
    if total_rows < 5:
        checks.append(
            DataQualityCheckSchema(
                id="sample_size_critical",
                name="Insufficient Records",
                category="sample_size",
                status="Critical",
                severity="critical",
                affected_columns=[],
                message=f"Dataset contains only {total_rows} rows. Statistical aggregations require at least 5-10 rows.",
                recommendation="Upload a dataset with at least 10-20 records for statistically meaningful analysis.",
            )
        )
        score -= 35
    elif total_rows < 20:
        checks.append(
            DataQualityCheckSchema(
                id="sample_size_small",
                name="Small Sample Size",
                category="sample_size",
                status="Warning",
                severity="warning",
                affected_columns=[],
                message=f"Dataset contains {total_rows} rows. Statistical confidence intervals may be wide.",
                recommendation="Interpret percentages and averages with caution due to limited sample size.",
            )
        )
        score -= 10
    else:
        checks.append(
            DataQualityCheckSchema(
                id="sample_size_pass",
                name="Sufficient Records",
                category="sample_size",
                status="Pass",
                severity="info",
                affected_columns=[],
                message=f"Dataset contains {total_rows:,} rows, sufficient for robust exploratory analytics.",
                recommendation="Sample size is adequate for standard descriptive and trend analysis.",
            )
        )

    # 2. Duplicate Rows Check
    dup_rows = int(df.duplicated().sum())
    dup_pct = round((dup_rows / total_rows) * 100.0, 2) if total_rows > 0 else 0.0
    if dup_rows > 0:
        sev: Literal["warning", "critical"] = "critical" if dup_pct > 10.0 else "warning"
        checks.append(
            DataQualityCheckSchema(
                id="duplicate_rows",
                name="Duplicate Rows Detected",
                category="duplicates",
                status="Critical" if sev == "critical" else "Warning",
                severity=sev,
                affected_columns=[],
                message=f"Found {dup_rows:,} duplicate rows ({dup_pct}% of total records).",
                recommendation="Deduplicate records prior to performing sum or count aggregations to avoid double-counting.",
            )
        )
        score -= 20 if sev == "critical" else 10
        recommendations.append("Apply row deduplication to ensure metrics are not artificially inflated.")
    else:
        checks.append(
            DataQualityCheckSchema(
                id="duplicate_rows_pass",
                name="No Duplicate Rows",
                category="duplicates",
                status="Pass",
                severity="info",
                affected_columns=[],
                message="All dataset rows are unique.",
                recommendation="No action needed.",
            )
        )

    # 3. Candidate Identifier Duplicates
    id_terms = ("order_id", "transaction_id", "invoice_id", "customer_id", "patient_id", "student_id", "employee_id", "id")
    for col in df.columns:
        col_str = str(col)
        col_lower = col_str.lower().strip()
        if any(col_lower == term or col_lower.endswith(f"_{term}") for term in id_terms):
            s = df[col].dropna()
            if not s.empty:
                col_dups = int(s.duplicated().sum())
                # If named order_id / transaction_id, it should usually be unique unless multi-item order
                if col_dups > 0 and col_lower in ("order_id", "transaction_id", "invoice_id", "id"):
                    checks.append(
                        DataQualityCheckSchema(
                            id=f"dup_id_{col_str}",
                            name=f"Duplicate Primary IDs in '{col_str}'",
                            category="duplicates",
                            status="Warning",
                            severity="warning",
                            affected_columns=[col_str],
                            message=f"Column '{col_str}' has {col_dups:,} duplicate values. (May indicate multi-line items or duplicate records).",
                            recommendation="Verify whether duplicate IDs represent multi-line orders or accidental duplicate submissions.",
                        )
                    )
                    score -= 5

    # 4. Column-by-column diagnostic analysis
    non_negative_keywords = (
        "price", "sales", "revenue", "cost", "amount", "quantity", "units",
        "age", "duration", "attendance", "score", "runs", "wickets", "views", "clicks", "spend"
    )
    denominator_keywords = ("impressions", "clicks", "balls_faced", "overs", "population", "total", "budget")

    for col in df.columns:
        col_str = str(col)
        col_lower = col_str.lower().strip()
        series = df[col]
        total_c = len(series)
        missing_c = int(series.isna().sum())
        missing_p = round((missing_c / total_c) * 100.0, 2) if total_c > 0 else 0.0
        unique_c = int(series.nunique())
        col_issues: List[str] = []

        is_numeric = pd.api.types.is_numeric_dtype(series) and not pd.api.types.is_bool_dtype(series)
        is_string = series.dtype == "object" or pd.api.types.is_string_dtype(series)

        neg_count = 0
        zero_count = 0
        outlier_count = 0
        dup_count = int(series.dropna().duplicated().sum())

        if missing_p > 40.0:
            col_issues.append(f"High missing rate ({missing_p}% nulls)")
        elif missing_p > 0.0:
            col_issues.append(f"{missing_c} missing values ({missing_p}%)")

        if unique_c == 1 and total_c > 1:
            col_issues.append("Constant value column (zero variance)")
        elif unique_c == 0:
            col_issues.append("Completely empty column")

        if is_numeric:
            num_s = pd.to_numeric(series, errors="coerce").dropna()
            if not num_s.empty:
                neg_count = int((num_s < 0).sum())
                zero_count = int((num_s == 0).sum())

                # Check suspicious negatives
                if neg_count > 0 and any(kw in col_lower for kw in non_negative_keywords):
                    col_issues.append(f"Contains {neg_count} suspicious negative values")

                # Check zero denominators
                if zero_count > 0 and any(kw in col_lower for kw in denominator_keywords):
                    col_issues.append(f"Contains {zero_count} zeros (potential division-by-zero in ratios)")

                # Outlier check (3x IQR)
                p25 = float(num_s.quantile(0.25))
                p75 = float(num_s.quantile(0.75))
                iqr = p75 - p25
                if iqr > 0:
                    lb = p25 - (3.0 * iqr)
                    ub = p75 + (3.0 * iqr)
                    outlier_count = int(((num_s < lb) | (num_s > ub)).sum())
                    if outlier_count > 0:
                        col_issues.append(f"{outlier_count} extreme statistical outliers (> 3x IQR)")

        if is_string:
            str_s = series.dropna().astype(str)
            if not str_s.empty:
                # Check for inconsistent casing or trailing whitespace
                stripped = str_s.str.strip()
                has_whitespace = (str_s != stripped).any()
                if has_whitespace:
                    col_issues.append("Contains values with leading/trailing whitespace")

                lower_s = stripped.str.lower()
                if lower_s.nunique() < stripped.nunique():
                    col_issues.append("Inconsistent casing across identical category names")

        column_diagnostics[col_str] = ColumnQualityDiagnosticSchema(
            column_name=col_str,
            dtype=str(series.dtype),
            total_count=total_c,
            missing_count=missing_c,
            missing_pct=missing_p,
            unique_count=unique_c,
            duplicate_count=dup_count,
            negative_count=neg_count,
            zero_count=zero_count,
            outlier_count=outlier_count,
            issues=col_issues,
        )

    # 5. Aggregate missing values across entire dataset
    total_cells = total_rows * total_cols
    total_nulls = int(df.isna().sum().sum())
    overall_null_pct = round((total_nulls / total_cells) * 100.0, 2) if total_cells > 0 else 0.0

    if overall_null_pct > 20.0:
        checks.append(
            DataQualityCheckSchema(
                id="high_missing_cells",
                name="Substantial Missing Data",
                category="missing_data",
                status="Critical",
                severity="critical",
                affected_columns=[c for c, d in column_diagnostics.items() if d.missing_pct > 20.0],
                message=f"Dataset has {overall_null_pct}% missing values across {len(checks)} columns.",
                recommendation="Impute missing values or exclude columns with over 50% missingness before building models.",
            )
        )
        score -= 25
        recommendations.append("Address high missingness in affected columns using domain-appropriate imputation or row filtering.")
    elif overall_null_pct > 5.0:
        checks.append(
            DataQualityCheckSchema(
                id="moderate_missing_cells",
                name="Moderate Missing Values",
                category="missing_data",
                status="Warning",
                severity="warning",
                affected_columns=[c for c, d in column_diagnostics.items() if d.missing_pct > 5.0],
                message=f"{overall_null_pct}% of dataset cells are missing.",
                recommendation="Verify whether missing values are missing at random or indicate skipped fields.",
            )
        )
        score -= 10
    else:
        checks.append(
            DataQualityCheckSchema(
                id="low_missing_cells_pass",
                name="High Data Completeness",
                category="missing_data",
                status="Pass",
                severity="info",
                affected_columns=[],
                message=f"Dataset is {100.0 - overall_null_pct:.1f}% complete.",
                recommendation="Data completeness is excellent.",
            )
        )

    # 6. Check for empty or constant columns
    empty_cols = [c for c, d in column_diagnostics.items() if d.unique_count == 0]
    constant_cols = [c for c, d in column_diagnostics.items() if d.unique_count == 1 and total_rows > 1]
    if empty_cols:
        checks.append(
            DataQualityCheckSchema(
                id="empty_columns",
                name="Completely Empty Columns",
                category="columns",
                status="Critical",
                severity="critical",
                affected_columns=empty_cols,
                message=f"{len(empty_cols)} columns are entirely empty: {', '.join(empty_cols)}.",
                recommendation="Drop completely empty columns from dataset.",
            )
        )
        score -= 15
    if constant_cols:
        checks.append(
            DataQualityCheckSchema(
                id="constant_columns",
                name="Constant-Value Columns",
                category="columns",
                status="Warning",
                severity="warning",
                affected_columns=constant_cols,
                message=f"{len(constant_cols)} columns have zero variance (single value): {', '.join(constant_cols)}.",
                recommendation="Constant columns provide no explanatory power for comparisons or predictive analysis.",
            )
        )
        score -= 5

    # 7. Check for suspicious negative values
    suspicious_neg_cols = [
        c for c, d in column_diagnostics.items()
        if d.negative_count > 0 and any(kw in c.lower() for kw in non_negative_keywords)
    ]
    if suspicious_neg_cols:
        checks.append(
            DataQualityCheckSchema(
                id="suspicious_negatives",
                name="Suspicious Negative Values",
                category="business_logic",
                status="Warning",
                severity="warning",
                affected_columns=suspicious_neg_cols,
                message=f"Negative values detected in naturally non-negative columns: {', '.join(suspicious_neg_cols)}.",
                recommendation="Audit negative values to ensure they reflect valid adjustments (e.g. refunds) rather than data entry errors.",
            )
        )
        score -= 10
        recommendations.append("Review negative values in financial or count measures to confirm they represent valid business transactions.")

    # 8. Date Parsing & Interval Checks
    date_cols = [c for c in df.columns if any(kw in str(c).lower() for kw in ("date", "time", "year", "month", "season"))]
    for dc in date_cols:
        raw_s = df[dc].dropna()
        if not raw_s.empty:
            parsed = pd.to_datetime(raw_s, errors="coerce")
            inv_count = int(parsed.isna().sum())
            if inv_count > 0:
                checks.append(
                    DataQualityCheckSchema(
                        id=f"invalid_dates_{dc}",
                        name=f"Invalid Date Formats in '{dc}'",
                        category="dates",
                        status="Warning",
                        severity="warning",
                        affected_columns=[str(dc)],
                        message=f"{inv_count} values in date column '{dc}' could not be parsed.",
                        recommendation="Standardize date strings into ISO 8601 (YYYY-MM-DD) format.",
                    )
                )
                score -= 8

    # Ensure score stays in 0-100 range
    final_score = max(0, min(100, score))

    crit_count = sum(1 for c in checks if c.severity == "critical")
    warn_count = sum(1 for c in checks if c.severity == "warning")
    info_count = sum(1 for c in checks if c.severity == "info")

    if final_score >= 80 and crit_count == 0:
        overall_status = "Healthy"
        summary = f"Dataset is in healthy condition (Score: {final_score}/100) with {info_count} passed checks and {warn_count} minor warnings."
    elif final_score >= 50:
        overall_status = "Warning"
        summary = f"Dataset has quality warnings (Score: {final_score}/100). {warn_count} warnings and {crit_count} critical issues require attention."
    else:
        overall_status = "Critical"
        summary = f"Significant data quality concerns identified (Score: {final_score}/100). {crit_count} critical issues should be addressed before decision-making."

    if not recommendations:
        recommendations.append("Dataset passed core hygiene validation checks; proceed with domain exploration and trend intelligence.")

    return DataQualityReportResponse(
        dataset_id=dataset_id,
        overall_score=final_score,
        status=overall_status,
        summary=summary,
        issue_counts={
            "critical": crit_count,
            "warning": warn_count,
            "info": info_count,
        },
        checks=checks,
        column_diagnostics=column_diagnostics,
        recommendations=recommendations,
    )
