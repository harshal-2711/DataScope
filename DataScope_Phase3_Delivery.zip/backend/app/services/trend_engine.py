"""Time-series trend intelligence engine.

Calculates verified trends, growth rates, moving averages, peaks, troughs,
period-over-period comparisons, volatility, anomaly spikes/drops, and answers
practical trend questions from actual dataset time series without speculative claims.
"""
from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from app.domains.base import TrendRule
from app.schemas.domain_blueprint import (
    CategoryTrendSchema,
    PeriodComparisonSchema,
    PracticalTrendAnswersSchema,
    SpikeDropSchema,
    TimeDimensionValidationSchema,
    TrendItemSchema,
    TrendPointSchema,
    TrendsIntelligenceResponse,
)


def _clean_float(val: Any, decimals: int = 2) -> Optional[float]:
    if val is None:
        return None
    try:
        f = float(val)
        if math.isnan(f) or math.isinf(f):
            return None
        return round(f, decimals)
    except (ValueError, TypeError):
        return None


def _find_time_column(df: pd.DataFrame) -> Optional[str]:
    """Identify the most appropriate time/date column in a dataset."""
    # 1. Check for native datetime dtypes
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            return str(col)

    # 2. Check column names with common date keywords
    date_keywords = (
        "date", "timestamp", "datetime", "order_date", "transaction_date",
        "created_at", "updated_at", "invoice_date", "match_date",
        "admission_date", "release_date", "event_date", "time", "year", "season"
    )
    col_scores: List[Tuple[float, str]] = []

    for col in df.columns:
        col_lower = str(col).strip().lower().replace(" ", "_").replace("-", "_")
        score = 0.0

        for kw in date_keywords:
            if kw == col_lower:
                score += 10.0
            elif kw in col_lower:
                score += 5.0

        # Test parsing a sample of non-null values
        if score > 0 or df[col].dtype == "object":
            sample = df[col].dropna().head(20)
            if not sample.empty:
                try:
                    parsed = pd.to_datetime(sample, errors="coerce")
                    valid_pct = parsed.notna().mean()
                    if valid_pct >= 0.7:
                        score += valid_pct * 15.0
                except Exception:
                    pass

        if score > 5.0:
            col_scores.append((score, str(col)))

    if col_scores:
        col_scores.sort(key=lambda x: x[0], reverse=True)
        return col_scores[0][1]

    return None


def _find_numeric_metrics(df: pd.DataFrame) -> List[str]:
    """Find valid continuous numeric metrics excluding pure IDs or indices."""
    metrics: List[str] = []
    id_terms = ("id", "_id", "code", "zip", "postal", "phone", "key", "number", "num")

    for col in df.columns:
        col_str = str(col)
        col_lower = col_str.lower().strip()
        if pd.api.types.is_numeric_dtype(df[col]) and not pd.api.types.is_bool_dtype(df[col]):
            if any(col_lower.endswith(t) or col_lower == t for t in id_terms):
                continue
            # Check unique values - if only 0 and 1, it's boolean
            non_null = df[col].dropna()
            if non_null.nunique() > 2:
                metrics.append(col_str)

    return metrics


def _find_categorical_dimensions(df: pd.DataFrame) -> List[str]:
    """Find good categorical grouping dimensions (cardinality between 2 and 40)."""
    categories: List[str] = []
    id_terms = ("id", "_id", "key", "uuid", "hash")

    for col in df.columns:
        col_str = str(col)
        col_lower = col_str.lower().strip()
        if any(col_lower.endswith(t) or col_lower == t for t in id_terms):
            continue
        if df[col].dtype == "object" or isinstance(df[col].dtype, pd.CategoricalDtype):
            nunique = df[col].nunique()
            if 2 <= nunique <= 40:
                categories.append(col_str)

    return categories


def compute_trends_intelligence(
    df: pd.DataFrame,
    dataset_id: str,
    granularity: str = "auto",
    metric: Optional[str] = None,
    category_col: Optional[str] = None,
) -> TrendsIntelligenceResponse:
    """Compute comprehensive time-series trends intelligence."""
    time_col = _find_time_column(df)
    numeric_metrics = _find_numeric_metrics(df)
    categories = _find_categorical_dimensions(df)

    # If no time column exists, return graceful unsupported state
    if not time_col:
        return TrendsIntelligenceResponse(
            dataset_id=dataset_id,
            has_time_dimension=False,
            time_validation=TimeDimensionValidationSchema(
                has_time_dimension=False,
                quality_status="No Time Dimension",
                notes=["No date, timestamp, or year column was detected in this dataset."],
            ),
            available_metrics=numeric_metrics,
            available_categories=categories,
            limitations=[
                "Dataset lacks a usable temporal dimension.",
                "Trends, period-over-period comparisons, and time-series forecasting cannot be calculated without dates.",
            ],
        )

    # Validate time column
    raw_series = df[time_col]
    total_rows = len(raw_series)
    missing_dates = int(raw_series.isna().sum())

    parsed_dates = pd.to_datetime(raw_series, errors="coerce")
    invalid_dates = int(raw_series.notna().sum() - parsed_dates.notna().sum())
    valid_dates_series = parsed_dates.dropna()

    if len(valid_dates_series) < 3:
        return TrendsIntelligenceResponse(
            dataset_id=dataset_id,
            has_time_dimension=False,
            time_validation=TimeDimensionValidationSchema(
                has_time_dimension=False,
                time_column=time_col,
                missing_dates_count=missing_dates,
                invalid_dates_count=invalid_dates,
                quality_status="Insufficient Dates",
                notes=["Fewer than 3 valid date records could be parsed from the time column."],
            ),
            available_metrics=numeric_metrics,
            available_categories=categories,
            limitations=["Insufficient valid date records to compute time-series trends."],
        )

    min_date = valid_dates_series.min()
    max_date = valid_dates_series.max()
    date_span_days = int((max_date - min_date).days)
    duplicate_dates = int(valid_dates_series.duplicated().sum())

    # Detect interval frequency
    sorted_unique_dates = valid_dates_series.drop_duplicates().sort_values()
    intervals = sorted_unique_dates.diff().dt.days.dropna()
    median_interval = float(intervals.median()) if len(intervals) > 0 else 0.0

    if median_interval <= 1.5:
        detected_freq = "daily"
    elif 6.0 <= median_interval <= 8.0:
        detected_freq = "weekly"
    elif 27.0 <= median_interval <= 32.0:
        detected_freq = "monthly"
    elif 85.0 <= median_interval <= 95.0:
        detected_freq = "quarterly"
    elif 350.0 <= median_interval <= 370.0:
        detected_freq = "yearly"
    else:
        detected_freq = "irregular"

    has_irregular = detected_freq == "irregular" or (len(intervals) > 2 and intervals.std() > 15)

    quality_status = "Healthy"
    notes: List[str] = []
    if missing_dates > 0:
        notes.append(f"{missing_dates} rows have missing date values.")
        quality_status = "Warning"
    if invalid_dates > 0:
        notes.append(f"{invalid_dates} rows contain unparseable date strings.")
        quality_status = "Warning"
    if has_irregular:
        notes.append("Time intervals between records are non-uniform.")

    time_validation = TimeDimensionValidationSchema(
        has_time_dimension=True,
        time_column=time_col,
        date_range={
            "min_date": min_date.strftime("%Y-%m-%d"),
            "max_date": max_date.strftime("%Y-%m-%d"),
            "total_days": date_span_days,
            "observation_count": len(valid_dates_series),
        },
        detected_frequency=detected_freq,
        missing_dates_count=missing_dates,
        invalid_dates_count=invalid_dates,
        duplicate_dates_count=duplicate_dates,
        has_irregular_intervals=has_irregular,
        quality_status=quality_status,
        notes=notes,
    )

    # Pick selected metric
    selected_metric = metric if (metric and metric in numeric_metrics) else (numeric_metrics[0] if numeric_metrics else None)

    if not selected_metric:
        return TrendsIntelligenceResponse(
            dataset_id=dataset_id,
            has_time_dimension=True,
            time_validation=time_validation,
            available_metrics=numeric_metrics,
            available_categories=categories,
            limitations=["Dataset contains a valid time dimension, but no continuous numeric metrics were found to aggregate over time."],
        )

    # Select granularity
    selected_granularity = granularity.upper()
    if selected_granularity not in ("D", "W", "M", "Q", "Y"):
        # Smart auto-granularity
        if date_span_days > 730:
            selected_granularity = "M" if date_span_days <= 1800 else "Q"
        elif date_span_days > 60:
            selected_granularity = "W" if date_span_days <= 180 else "M"
        else:
            selected_granularity = "D"

    # Prepare DataFrame for time aggregation
    clean_df = pd.DataFrame({
        "date": parsed_dates,
        "metric": pd.to_numeric(df[selected_metric], errors="coerce"),
    })
    if category_col and category_col in df.columns:
        clean_df["category"] = df[category_col].astype(str)

    clean_df = clean_df.dropna(subset=["date", "metric"]).sort_values("date")

    if len(clean_df) < 2:
        return TrendsIntelligenceResponse(
            dataset_id=dataset_id,
            has_time_dimension=True,
            time_validation=time_validation,
            available_metrics=numeric_metrics,
            available_categories=categories,
            selected_metric=selected_metric,
            selected_granularity=selected_granularity,
            limitations=["Insufficient non-null rows to compute trend aggregations."],
        )

    # Aggregate by selected period
    clean_df["period"] = clean_df["date"].dt.to_period(selected_granularity).dt.to_timestamp()
    ts = clean_df.groupby("period")["metric"].sum()

    if len(ts) < 2:
        # Fallback to daily or finer if period collapsed everything to 1 row
        clean_df["period"] = clean_df["date"].dt.to_period("D").dt.to_timestamp()
        ts = clean_df.groupby("period")["metric"].sum()
        selected_granularity = "D"

    # Moving averages
    ma_3 = ts.rolling(window=min(3, len(ts)), min_periods=1).mean()
    ma_7 = ts.rolling(window=min(7, len(ts)), min_periods=1).mean()

    # Outlier / Anomaly detection: residuals from rolling mean
    mean_val = float(ts.mean())
    std_val = float(ts.std()) if len(ts) > 1 else 0.0

    time_series_points: List[TrendPointSchema] = []
    spikes_and_drops: List[SpikeDropSchema] = []

    for dt, val, m3, m7 in zip(ts.index, ts.values, ma_3.values, ma_7.values):
        v = float(val)
        is_spike = False
        is_drop = False
        sigma = 0.0

        if std_val > 0:
            sigma = (v - mean_val) / std_val
            if sigma >= 2.0:
                is_spike = True
                spikes_and_drops.append(
                    SpikeDropSchema(
                        date=dt.strftime("%Y-%m-%d"),
                        value=round(v, 2),
                        expected_value=round(mean_val, 2),
                        deviation_sigma=round(sigma, 2),
                        type="spike",
                        description=f"Significant spike of {round(v, 2):,} ({round(sigma, 1)}σ above average).",
                    )
                )
            elif sigma <= -2.0:
                is_drop = True
                spikes_and_drops.append(
                    SpikeDropSchema(
                        date=dt.strftime("%Y-%m-%d"),
                        value=round(v, 2),
                        expected_value=round(mean_val, 2),
                        deviation_sigma=round(sigma, 2),
                        type="drop",
                        description=f"Significant drop to {round(v, 2):,} ({round(abs(sigma), 1)}σ below average).",
                    )
                )

        time_series_points.append(
            TrendPointSchema(
                date=dt.strftime("%Y-%m-%d"),
                formatted_date=dt.strftime("%b %Y" if selected_granularity in ("M", "Q", "Y") else "%Y-%m-%d"),
                value=round(v, 2),
                moving_avg_3=round(float(m3), 2),
                moving_avg_7=round(float(m7), 2),
                is_spike=is_spike,
                is_drop=is_drop,
                anomaly_score=round(sigma, 2) if std_val > 0 else None,
            )
        )

    # Period-over-period comparison (latest vs prior)
    current_period_idx = ts.index[-1]
    previous_period_idx = ts.index[-2]
    current_val = float(ts.iloc[-1])
    previous_val = float(ts.iloc[-2])
    abs_change = current_val - previous_val
    pct_change = round(((current_val - previous_val) / previous_val) * 100.0, 2) if previous_val != 0 else None

    growth_dir = "increasing" if abs_change > 0 else ("decreasing" if abs_change < 0 else "stable")

    best_idx = ts.idxmax()
    best_val = float(ts.max())
    worst_idx = ts.idxmin()
    worst_val = float(ts.min())

    period_comp = PeriodComparisonSchema(
        current_period=current_period_idx.strftime("%Y-%m-%d"),
        previous_period=previous_period_idx.strftime("%Y-%m-%d"),
        current_val=round(current_val, 2),
        previous_val=round(previous_val, 2),
        absolute_change=round(abs_change, 2),
        pct_change=pct_change,
        growth_direction=growth_dir,
        best_period=best_idx.strftime("%Y-%m-%d"),
        best_val=round(best_val, 2),
        worst_period=worst_idx.strftime("%Y-%m-%d"),
        worst_val=round(worst_val, 2),
    )

    # Volatility
    cv = (std_val / mean_val) if mean_val > 0 else 0.0
    if cv < 0.15:
        stability = "Stable (Low Volatility)"
    elif cv < 0.40:
        stability = "Moderate Volatility"
    else:
        stability = "High Volatility"

    # Category-wise trends
    category_trends: List[CategoryTrendSchema] = []
    categories_increased: List[str] = []
    categories_declined: List[str] = []

    cat_to_use = category_col if (category_col and category_col in df.columns) else (categories[0] if categories else None)

    if cat_to_use and "category" in clean_df.columns:
        top_cats = clean_df["category"].value_counts().head(5).index.tolist()
        for cat in top_cats:
            cat_df = clean_df[clean_df["category"] == cat]
            cat_ts = cat_df.groupby("period")["metric"].sum()
            if len(cat_ts) >= 2:
                c_prev = float(cat_ts.iloc[-2]) if len(cat_ts) >= 2 else 0.0
                c_curr = float(cat_ts.iloc[-1])
                c_diff = c_curr - c_prev
                c_pct = round(((c_curr - c_prev) / c_prev) * 100.0, 2) if c_prev != 0 else None
                c_dir = "increasing" if c_diff > 0 else ("decreasing" if c_diff < 0 else "stable")

                if c_diff > 0:
                    categories_increased.append(str(cat))
                elif c_diff < 0:
                    categories_declined.append(str(cat))

                series_pts = [
                    {"date": dt.strftime("%Y-%m-%d"), "value": round(float(v), 2)}
                    for dt, v in cat_ts.items()
                ]

                category_trends.append(
                    CategoryTrendSchema(
                        category=str(cat),
                        previous_val=round(c_prev, 2),
                        current_val=round(c_curr, 2),
                        absolute_change=round(c_diff, 2),
                        pct_change=c_pct,
                        direction=c_dir,
                        series=series_pts,
                    )
                )

    # 12 Practical Trend Questions & Answers
    metric_label = selected_metric.replace("_", " ").capitalize()
    pct_str = f"{pct_change:+0.1f}%" if pct_change is not None else "N/A"
    abs_str = f"{abs_change:+,.2f}"

    practical_answers = PracticalTrendAnswersSchema(
        metric_analyzed=f"{metric_label} (aggregated by {selected_granularity}-frequency period)",
        previous_value_text=f"{previous_val:,.2f} recorded in period {previous_period_idx.strftime('%Y-%m-%d')}",
        current_value_text=f"{current_val:,.2f} recorded in latest period {current_period_idx.strftime('%Y-%m-%d')}",
        absolute_change_text=f"Net change of {abs_str}",
        pct_change_text=f"Percentage change of {pct_str}",
        best_period_text=f"Peak value of {best_val:,.2f} on {best_idx.strftime('%Y-%m-%d')}",
        worst_period_text=f"Trough value of {worst_val:,.2f} on {worst_idx.strftime('%Y-%m-%d')}",
        categories_increased=categories_increased[:5],
        categories_declined=categories_declined[:5],
        stability_text=f"{stability} (Coefficient of Variation: {round(cv, 3)})",
        outliers_text=f"{len(spikes_and_drops)} statistical spikes or drops detected beyond ±2σ baseline",
        next_investigation_text=(
            f"Investigate operational drivers behind the {growth_dir} trajectory in the latest period. "
            f"Check whether leading segments like {', '.join(categories_increased[:2]) if categories_increased else 'top contributors'} "
            f"reflect sustainable performance or temporary variance."
        ),
    )

    limitations = [
        "Historical observation only. Descriptive trends reflect recorded data and do not establish causal relationships.",
        "External market dynamics, seasonal shifts, and unrecorded variables cannot be verified from internal columns alone.",
    ]
    if len(ts) < 12:
        limitations.append("Time series contains fewer than 12 periods; long-term cyclical patterns and annual seasonality cannot be reliably concluded.")

    return TrendsIntelligenceResponse(
        dataset_id=dataset_id,
        has_time_dimension=True,
        time_validation=time_validation,
        available_metrics=numeric_metrics,
        available_categories=categories,
        selected_metric=selected_metric,
        selected_granularity=selected_granularity,
        period_comparison=period_comp,
        volatility_cv=round(cv, 4),
        stability_rating=stability,
        time_series=time_series_points,
        category_trends=category_trends,
        spikes_and_drops=spikes_and_drops,
        practical_answers=practical_answers,
        limitations=limitations,
    )


def compute_trends(
    df: pd.DataFrame,
    validated_trends: List[Tuple[TrendRule, str, str]],
) -> List[TrendItemSchema]:
    """Calculate statistical time-series trends, peaks, troughs, and growth rates.
    Maintained for backward compatibility with blueprint rules.
    """
    results: List[TrendItemSchema] = []

    for rule, metric_col, date_col in validated_trends:
        if date_col not in df.columns or metric_col not in df.columns:
            continue

        clean_df = df[[date_col, metric_col]].dropna().copy()
        if clean_df.empty:
            continue

        try:
            clean_df["parsed_date"] = pd.to_datetime(clean_df[date_col], errors="coerce")
            clean_df = clean_df.dropna(subset=["parsed_date"])
            if len(clean_df) < 3:
                continue

            clean_df = clean_df.sort_values("parsed_date")

            date_range = clean_df["parsed_date"].max() - clean_df["parsed_date"].min()
            days = date_range.days

            if days > 730:
                clean_df["period"] = clean_df["parsed_date"].dt.to_period("Y").dt.to_timestamp()
            elif days > 60:
                clean_df["period"] = clean_df["parsed_date"].dt.to_period("M").dt.to_timestamp()
            else:
                clean_df["period"] = clean_df["parsed_date"].dt.to_period("D").dt.to_timestamp()

            ts = clean_df.groupby("period")[metric_col].sum()
            if len(ts) < 2:
                continue

            start_val = float(ts.iloc[0])
            end_val = float(ts.iloc[-1])
            growth_pct: Optional[float] = None
            if start_val > 0:
                growth_pct = round(((end_val - start_val) / start_val) * 100.0, 1)

            peak_idx = ts.idxmax()
            peak_val = float(ts.max())
            peak_str = peak_idx.strftime("%Y-%m-%d")

            trough_idx = ts.idxmin()
            trough_val = float(ts.min())
            trough_str = trough_idx.strftime("%Y-%m-%d")

            x = np.arange(len(ts))
            y = ts.values.astype(float)
            slope, _ = np.polyfit(x, y, 1) if len(x) >= 2 else (0.0, 0.0)

            if slope > 0.05 * np.std(y):
                direction = "increasing"
            elif slope < -0.05 * np.std(y):
                direction = "decreasing"
            else:
                direction = "stable"

            ma = ts.rolling(window=min(3, len(ts)), min_periods=1).mean()

            data_points: List[Dict[str, Any]] = [
                {
                    "date": dt.strftime("%Y-%m-%d"),
                    "value": round(float(v), 2),
                    "moving_avg": round(float(m), 2),
                }
                for dt, v, m in zip(ts.index, ts.values, ma.values)
            ]

            desc = f"{metric_col.capitalize()} is {direction} over the observation window"
            if growth_pct is not None:
                desc += f" (net change: {growth_pct:+0.1f}%)"
            desc += f". Peak of {round(peak_val, 2):,} on {peak_str}."

            results.append(
                TrendItemSchema(
                    metric_name=metric_col,
                    time_column=date_col,
                    trend_direction=direction,
                    growth_rate_pct=growth_pct,
                    peak_period=peak_str,
                    trough_period=trough_str,
                    seasonality_detected=False,
                    description=desc,
                    data_points=data_points,
                )
            )
        except Exception:
            continue

    return results
